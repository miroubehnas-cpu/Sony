package com.amir.sonymonitor

import android.graphics.Color
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.jiangdg.ausbc.MultiCameraClient
import com.jiangdg.ausbc.base.CameraFragment
import com.jiangdg.ausbc.camera.bean.CameraRequest
import com.jiangdg.ausbc.callback.ICameraStateCallBack
import com.jiangdg.ausbc.render.env.RotateType
import com.jiangdg.ausbc.widget.AspectRatioTextureView
import com.jiangdg.ausbc.widget.IAspectRatio

/**
 * UVC preview screen. AUSBC handles USB attach, permission and stream lifecycle.
 * Actual camera output still requires a real UVC capture card and USB-host-capable phone.
 */
class UvcMonitorFragment : CameraFragment() {
    private lateinit var previewContainer: FrameLayout
    private lateinit var statusText: TextView
    private lateinit var formatButton: Button
    private var useMjpeg = true
    private var previewView: AspectRatioTextureView? = null

    override fun getRootView(inflater: LayoutInflater, container: ViewGroup?): View {
        val context = requireContext()
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.rgb(8, 10, 13))
        }

        root.addView(TextView(context).apply {
            text = "SONY MONITOR PRO  •  HDMI / UVC"
            textSize = 19f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(226, 184, 94))
            setPadding(4, 6, 4, 10)
        })

        previewContainer = FrameLayout(context).apply {
            setBackgroundColor(Color.BLACK)
        }
        root.addView(previewContainer, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        formatButton = Button(context).apply {
            text = "Switch to YUYV fallback"
            isAllCaps = false
            setOnClickListener { switchPreviewFormat() }
        }
        root.addView(formatButton)

        statusText = TextView(context).apply {
            text = "Connect the HDMI capture card through USB-C / OTG."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(6, 12, 6, 8)
        }
        root.addView(statusText)
        return root
    }

    override fun getCameraView(): IAspectRatio {
        return previewView ?: AspectRatioTextureView(requireContext()).also { previewView = it }
    }

    override fun getCameraViewContainer(): ViewGroup = previewContainer

    override fun getGravity(): Int = Gravity.CENTER

    override fun getCameraRequest(): CameraRequest {
        return CameraRequest.Builder()
            .setPreviewWidth(1280)
            .setPreviewHeight(720)
            .setRenderMode(CameraRequest.RenderMode.OPENGL)
            .setDefaultRotateType(RotateType.ANGLE_0)
            .setPreviewFormat(
                if (useMjpeg) CameraRequest.PreviewFormat.FORMAT_MJPEG
                else CameraRequest.PreviewFormat.FORMAT_YUYV
            )
            .setAspectRatioShow(true)
            .setCaptureRawImage(false)
            .setRawPreviewData(false)
            .create()
    }

    private fun switchPreviewFormat() {
        useMjpeg = !useMjpeg
        formatButton.text = if (useMjpeg) "Switch to YUYV fallback" else "Switch to MJPEG"
        val camera = getCurrentCamera()
        val view = previewView
        if (camera == null || view == null) {
            statusText.text = "Format selected. Connect a UVC capture card to start preview."
            return
        }
        statusText.text = "Reopening UVC preview with ${if (useMjpeg) "MJPEG" else "YUYV"}…"
        camera.closeCamera()
        statusText.postDelayed({
            camera.openCamera(view, getCameraRequest())
        }, 500)
    }

    override fun onCameraState(
        self: MultiCameraClient.ICamera,
        code: ICameraStateCallBack.State,
        msg: String?
    ) {
        statusText.post {
            statusText.text = when (code) {
                ICameraStateCallBack.State.OPENED ->
                    "UVC camera opened. If the preview is black, check HDMI input and capture-card format."
                ICameraStateCallBack.State.CLOSED -> "UVC camera closed."
                ICameraStateCallBack.State.ERROR -> "UVC error: ${msg ?: "unknown camera error"}"
            }
        }
    }
}
