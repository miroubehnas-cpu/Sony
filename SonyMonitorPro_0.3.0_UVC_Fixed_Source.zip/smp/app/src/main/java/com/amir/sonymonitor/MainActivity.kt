package com.amir.sonymonitor

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var usbManager: UsbManager
    private lateinit var status: TextView
    private lateinit var deviceList: LinearLayout

    private val permissionAction = "com.amir.sonymonitor.USB_PERMISSION"
    private var receiverRegistered = false

    private val usbPermissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != permissionAction) return
            val device = intent.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
            val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
            status.text = if (granted) {
                "USB permission granted: ${device?.deviceName ?: "device"}"
            } else {
                "USB permission was not granted"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(USB_SERVICE) as UsbManager
        registerUsbReceiver()
        buildUi()
    }

    private fun registerUsbReceiver() {
        if (receiverRegistered) return
        val filter = IntentFilter(permissionAction)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(usbPermissionReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(usbPermissionReceiver, filter)
        }
        receiverRegistered = true
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 22, 24, 22)
            setBackgroundColor(Color.rgb(8, 10, 13))
        }

        root.addView(TextView(this).apply {
            text = "SONY MONITOR PRO"
            textSize = 26f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(226, 184, 94))
        })
        root.addView(TextView(this).apply {
            text = "RX10 IV  •  HDMI / UVC / WI-FI"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(0, 5, 0, 18)
        })

        status = TextView(this).apply {
            text = "HDMI preview is provided by the UVC monitor screen."
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(8, 10, 8, 14)
        }
        root.addView(status)

        root.addView(makeButton("OPEN HDMI / USB-C MONITOR") {
            startActivity(Intent(this, UvcMonitorActivity::class.java))
        })
        root.addView(makeButton("SCAN USB DEVICES") { scanUsbDevices() })
        root.addView(makeButton("WI-FI / SONY LIVE VIEW STATUS") { showWifiStatus() })
        root.addView(makeButton("OPEN SONY IMAGING EDGE MOBILE PAGE") {
            openUrl("https://www.sony.net/iem/")
        })

        val scroll = ScrollView(this)
        deviceList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(deviceList)
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(45, 49, 56))
        setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, 5, 0, 5)
        layoutParams = lp
    }

    private fun scanUsbDevices() {
        deviceList.removeAllViews()
        val devices = usbManager.deviceList.values.toList()
        status.text = "USB devices detected: ${devices.size}"
        if (devices.isEmpty()) {
            deviceList.addView(TextView(this).apply {
                text = "No USB device detected. Check OTG and the capture card's data connection."
                setTextColor(Color.LTGRAY)
                setPadding(8, 12, 8, 12)
            })
            return
        }

        devices.forEach { device ->
            deviceList.addView(makeButton(
                "${device.deviceName}  •  VID ${device.vendorId} / PID ${device.productId}"
            ) {
                val pendingIntent = PendingIntent.getBroadcast(
                    this,
                    device.deviceId,
                    Intent(permissionAction).setPackage(packageName),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
                )
                usbManager.requestPermission(device, pendingIntent)
                status.text = "Waiting for USB permission…"
            })
        }
    }

    private fun showWifiStatus() {
        status.text = "RX10 IV Wi-Fi control is supported through Sony Imaging Edge Mobile. " +
            "Direct Live View inside Sony Monitor Pro is not implemented or verified yet."
        deviceList.removeAllViews()
        deviceList.addView(TextView(this).apply {
            text = "1. Enable Ctrl w/ Smartphone on the RX10 IV.\n" +
                "2. Pair/connect using Sony Imaging Edge Mobile.\n" +
                "3. Use the Sony app for its supported remote shooting / Live View.\n\n" +
                "Sony's Camera Remote Command reference lists DSC-RX10M4 and Wi-Fi, " +
                "but the model-specific live-view command matrix must be checked before " +
                "implementing an in-app stream."
            textSize = 15f
            setTextColor(Color.LTGRAY)
            setPadding(8, 14, 8, 14)
        })
    }

    private fun openUrl(url: String) {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    override fun onDestroy() {
        if (receiverRegistered) {
            try { unregisterReceiver(usbPermissionReceiver) } catch (_: Exception) { }
            receiverRegistered = false
        }
        super.onDestroy()
    }
}
