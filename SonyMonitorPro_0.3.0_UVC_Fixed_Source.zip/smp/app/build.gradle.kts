plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.amir.sonymonitor"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.amir.sonymonitor"
        minSdk = 23
        targetSdk = 35
        versionCode = 3
        versionName = "0.3.0-uvc"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    // Official AUSBC coordinates. The project documents OTG/UVC support and
    // armeabi-v7a, arm64-v8a, x86 and x86_64 native support.
    implementation("com.github.ernestp.AndroidUSBCamera:libausbc:3.6.0")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
}
