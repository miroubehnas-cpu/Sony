# Sony Monitor Pro — 0.2.0 UVC integration candidate

تطبيق Android لمراقبة كاميرا Sony RX10 IV عبر بطاقة HDMI-to-USB UVC، مع مسار إرشادي للاتصال اللاسلكي.

## ما أُضيف في هذه النسخة المصدرية

- إصلاح عدم توافق JVM: Java وKotlin كلاهما يستهدفان JVM 17.
- خفض الحد الأدنى إلى Android 6.0 (API 23) وفق متطلبات AUSBC.
- دمج مكتبة AUSBC 3.6.0 عبر JitPack، وهي النسخة النشطة من محرك Android UVC.
- شاشة UVC فعلية في الكود تستخدم `CameraFragment` و`AspectRatioTextureView`، وتطلب 1280×720 وMJPEG مع تعطيل التقاط الصوت.
- مسار USB permission واكتشاف UVC تديره المكتبة، مع طلب إذن Android Camera قبل فتح UVC لأن AUSBC يفحص هذا الإذن عند targetSdk 28 وما بعده.
- تحديث استقبال USB الديناميكي في الشاشة الرئيسية ليستخدم `RECEIVER_NOT_EXPORTED` على Android 13+.
- إضافة GitHub Actions لبناء APK Debug ورفعه كـ Artifact عند نجاح البناء.
- توثيق حالة Wi-Fi ومصفوفة الاختبارات المطلوبة.

## توصيل HDMI

Sony RX10 IV (Micro-HDMI OUT) → بطاقة التقاط HDMI متوافقة UVC → USB-C/OTG → هاتف Android يدعم USB Host.

الكابل وحده لا يكفي. توافق الهاتف مع USB Host، بطاقة الالتقاط، صيغة MJPEG/YUYV، الطاقة، ودقة HDMI كلها عوامل مؤثرة.

## Wi-Fi: ما المؤكد وما لم يُثبت

- مرجع Sony Camera Remote Command يدرج DSC-RX10M4 وواجهة Wi-Fi، لكنه موجه للشركات، ويتطلب أحدث Firmware.
- تحذر Sony من أن Live View Monitoring غير مدعوم لبعض الطرازات؛ يلزم فحص جدول الأوامر الخاص بـ RX10M4 قبل كتابة بروتوكول البث.
- التحكم بالهاتف عبر Sony Imaging Edge Mobile هو المسار الاستهلاكي الموثق.
- لا يوجد في هذه النسخة بث Wi-Fi مباشر داخل التطبيق.

التفاصيل: `docs/WIFI_RX10_IV_STATUS.md`.

## البناء

المتطلبات: JDK 17، Gradle 8.9، Android SDK Platform 35، اتصال إنترنت لتنزيل AGP/Kotlin/AUSBC من المستودعات.

من جذر المشروع:

```bash
gradle --no-daemon :app:assembleDebug
```

أو افتح المشروع في Android Studio مع Gradle 8.9. في GitHub، سيعمل workflow الموجود في `.github/workflows/android.yml` ويضع APK في Artifacts عند نجاح البناء.

## الحالة والقيود

هذه **نسخة مصدرية مرشحة للدمج** وليست APK مثبتاً أو مختبراً. لم تتوفر في بيئة إعداد هذه النسخة Gradle أو Android SDK أو اتصال شبكي لتنزيل الاعتماديات، لذلك لم أستطع تنفيذ البناء هنا. كما لم يتوفر هاتف Android أو بطاقة UVC أو RX10 IV للاختبار الفعلي. لا نؤكد بعد نجاح عرض الفيديو على جهاز فعلي أو بث Wi-Fi داخل التطبيق.

قبل اعتبارها جاهزة: يجب أن ينجح GitHub Actions، ثم اختبار بطاقة HDMI حقيقية على عدة معماريات Android، ومراجعة سجل AUSBC عند فشل التفاوض.

## الترخيص

AUSBC مرخص Apache-2.0 حسب مستودعه. راجع تراخيص الاعتماديات الأصلية قبل توزيع التطبيق.


## مراجعة 0.2.2
- تم تصحيح إحداثيات اعتماد AUSBC إلى الإحداثيات الرسمية للمشروع.
- أزيل طلب CAMERA من التطبيق لأن AUSBC يعلن أن فتح UVC يتم دون صلاحية كاميرا نظامية؛ يبقى التحقق العملي مطلوباً على هاتف حقيقي.
- لم يتم إنتاج APK أو اختبار بطاقة الالتقاط في هذه البيئة.


## النسخة 0.3.0 – تصحيح الاعتماديات

تم تحويل محرك UVC إلى النسخة النشطة من AUSBC: `com.github.ernestp.AndroidUSBCamera:libausbc:3.6.0` بدلاً من المستودع القديم. الحد الأدنى Android 6 (API 23)، مع ترك المكتبة توفر معماريات ARM32 وARM64 وx86 وx86_64. أزيل استدعاء AudioSource.NONE غير المؤكد واستدعاء clear() غير الضروري.

**تنبيه:** هذه نسخة مصدرية مصححة. لم يتم تأكيد نجاح Gradle build أو إنتاج APK أو عرض فيديو على بطاقة التقاط حقيقية في بيئة هذه الجولة.
