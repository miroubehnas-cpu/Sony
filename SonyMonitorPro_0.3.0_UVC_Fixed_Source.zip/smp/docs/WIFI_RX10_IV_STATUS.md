# RX10 IV Wi‑Fi status

Sony's public Imaging Edge Mobile documentation describes smartphone remote operation and a Live View screen for supported cameras. Sony's RX10M4 support article also states that Imaging Edge Mobile can act as a remote commander with operations such as shutter release, record start/stop, and zoom.

This does **not** prove that Sony exposes a documented, stable, third-party Wi‑Fi Live View protocol for a custom Android app. The app therefore keeps Wi‑Fi as a documented/experimental path and does not claim that in-app wireless Live View works.

Recommended validation with the real camera:

1. Confirm the RX10 IV firmware version.
2. Pair the camera with Imaging Edge Mobile.
3. Verify Live View and remote shooting in Sony's app.
4. Capture network traffic only for lawful interoperability testing and only if the camera/app terms permit it.
5. Treat HDMI-to-UVC as the primary reliable monitor path.
