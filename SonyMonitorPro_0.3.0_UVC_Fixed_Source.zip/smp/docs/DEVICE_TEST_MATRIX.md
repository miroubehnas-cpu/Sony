# Device test matrix (not yet executed)

## USB / HDMI

- [ ] Android 6–8, ARMv7, OTG host, 720p MJPEG capture card
- [ ] Android 9–11, ARM64, OTG host, 720p MJPEG capture card
- [ ] Android 12–13, ARM64, OTG host, 1080p MJPEG capture card
- [ ] Android 14–16, ARM64, OTG host, 1080p capture card
- [ ] x86_64 Android emulator/device (USB passthrough required)
- [ ] Capture card YUYV-only fallback
- [ ] Unplug/replug during preview
- [ ] Background/foreground lifecycle and USB permission persistence
- [ ] Thermal and sustained 30 fps test for at least 20 minutes

## RX10 IV source

- [ ] Set HDMI output to clean output as required by the monitoring workflow
- [ ] Verify 720p and 1080p HDMI timings against the capture card
- [ ] Verify camera overlays/menus and record-state output
- [ ] Check HDMI audio separately; current preview request disables audio capture

## Wi-Fi

- [ ] Pair RX10 IV with Imaging Edge Mobile
- [ ] Confirm remote shooting / Live View in Sony app on current firmware
- [ ] Obtain authorized Sony Camera Remote Command compatibility matrix
- [ ] Confirm RX10M4 `Live View Monitoring` command support over WLAN
- [ ] Only then implement and test in-app PTP/IP stream handling
