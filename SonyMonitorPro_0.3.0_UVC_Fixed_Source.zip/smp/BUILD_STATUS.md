# Build and verification report

Date: 2026-11-18

## Source status

- Java and Kotlin targets are aligned to JVM 17.
- AUSBC-based UVC preview screen is present in `UvcMonitorFragment.kt`.
- The app requests USB access through the launcher flow and exposes a UVC monitor activity.
- GitHub Actions workflow is included for Java 17 + Android SDK 35 + `:app:assembleDebug`.
- The project archive contains no generated APK.

## Verification completed in this run

- Inspected the source archive and confirmed the UVC preview integration, USB permission flow, and build workflow are present.
- Confirmed the project includes JitPack in `settings.gradle.kts`, which is required by the AUSBC dependency declaration.
- Confirmed the previous JVM mismatch is addressed by `sourceCompatibility = 17`, `targetCompatibility = 17`, and `kotlinOptions.jvmTarget = "17"`.
- Re-checked Sony's current Imaging Edge Mobile documentation: Sony documents remote operation with a smartphone and Live View/remote-shooting UI, but the exact RX10 IV support and an open protocol for third-party apps were not verified from public documentation.

## Not verified

- Gradle compilation or dependency resolution in this environment.
- APK assembly, signing, installation, or runtime behavior.
- Actual UVC preview with a physical HDMI capture card and Sony RX10 IV.
- Compatibility across specific phones, Android versions, USB chipsets, or capture-card modes.
- Direct RX10 IV Wi-Fi Live View inside this app.

## First authoritative build

Push the project to GitHub with Actions enabled and run the included `Android APK` workflow. A successful run should produce `app/build/outputs/apk/debug/app-debug.apk` as the `sony-monitor-pro-debug-apk` artifact.


## Review 2026-11-19
- Fixed the AUSBC Maven coordinates to the official project coordinates: `com.github.jiangdongguo.AndroidUSBCamera:libausbc:3.6.0`.
- Removed the app-level CAMERA permission gate to match AUSBC's documented USB/UVC permission model; runtime behavior still requires a physical-device test.
- APK build was not executed here because Gradle/Android SDK are not available in the current environment.


## 0.3.0 source correction (2026-11-19)
- Switched AUSBC dependency to the actively maintained canonical fork: `com.github.ernestp.AndroidUSBCamera:libausbc:3.6.0`.
- Kept API level 23 minimum and all ABIs provided by the library (armeabi-v7a, arm64-v8a, x86, x86_64).
- Removed the unverified `CameraRequest.AudioSource.NONE` enum usage; audio is not requested/configured by this app.
- Removed an unverified `clear()` override from the UVC fragment.
- Added explicit preview gravity.
- Build and physical UVC testing are still pending; this is a source correction, not a verified APK.
